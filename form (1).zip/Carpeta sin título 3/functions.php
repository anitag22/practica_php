<?php
function validarDatos($datos){
  $errores = [];
  if ($datos["name"]=="") {
   $errores["name"]="Por favor ingrese su nombre";
  }
  if ($datos["email"]=="") {
    $errores["email"]="Por favor ingrese su email";
  }elseif (!filter_var($datos["email"],FILTER_VALIDATE_EMAIL)) {
    $errores["email"]="Por favor ingrese un email valido";
  }if ($datos["username"]=="") {
   $errores["username"]="Por favor ingrese su usuario";
  }
  if ($datos["password"]=="") {
    $errores["password"]= "Por favor ingrese una contraseña";
  }
  if ($datos ["cpassword"]=="") {
    $errores["cpassword"]= "Por favor reingrese su contraseña";
  }elseif ($datos["password"]!==$datos["cpassword"]) {
    $errores["cpassword"]="Las contraseñas no coinciden";
  }

  return $errores;

}
function crearUsuario($datos){
  return [
    "nombre" => $datos["name"],
    "mail" => $datos["email"],
    "usuario" => $datos ["username"],
    "password" => password_hash($datos["password"],PASSWORD_DEFAULT),
  ];

}

function guardarUsuario($usuario){
  $json= json_encode($usuario);
  file_put_contents("usuarios.json",$json.PHP_EOL,FILE_APPEND);
}


 ?>
